<?php

?>
<!DOCTYPE html>
<html>
   <head>
      <style>
         #section2 {
            display: none;
         }
         #section3 {
            display: none;
         }
      </style>
      <script>
         document.addEventListener('DOMContentLoaded',init);
         function handle_section1_next() {
            const div_section2 = document.getElementById("section2");
            div_section2.style = "display: block";
            const div_section1 = document.getElementById("section1");
            div_section1.style = "display: none";
            console.log("handle_section1_next() called");
         }
         function handle_section2_next() {
            const div_section2 = document.getElementById("section2");
            div_section2.style = "display: none";
            const div_section3 = document.getElementById("section3");
            div_section3.style = "display: block";
         }
         function init() {
            const section1_next = 
               document.getElementById("section1_next");
            section1_next.addEventListener('click',
               handle_section1_next);
            const section2_next = 
               document.getElementById("section2_next");
            section2_next.addEventListener('click',
               handle_section2_next);
         }
      </script>
   </head>
   <body>
      <div id="data_entry">
         <form action="handle_desk_entry.php" method="post">
            <div id="section1">
            Date (YYYY-MM-DD):
            <input type="text" name="sighting_date"><br>
            <br>
            Select beach/location: <br>
            <select name="beach_location" size="4">
               <option>Laniakea Beach</option>
               <option>Maluaka Beach</option>
               <option>Kiholo Bay</option>
               <option>Punalu'u Beach</option>
            </select><br><br>
            GPS coords (lat, long) (ex: 21.61801,-158.08846)
            <input type="text" name="gps_string"><br><br>
            <button id="section1_next" type="button">Next</button>
            </div>
            <div id="section2">
            Select turtle_type: <br>
            <select name="turtle_type" size="5">
               <option value="Cm">Green turtle</option>
               <option value="Ei">Hawksbill turtle</option>
               <option value="Cc">Loggerhead turtle</option>
               <option value="Dc">Leatherback turtle</option>
               <option value="Lo">Olive Ridley turtle</option>
            </select><br><br>
            <button id="section2_next" type="button">Next</button>
            </div>
            <div id="section3">
            Add other_notes, check all the apply: <br>
            <input type="checkbox" name="other_notes[]" 
               value="lying still on the shoreline">
            lying still on the shoreline<br>
            <input type="checkbox" name="other_notes[]"
               value="open wound or bleeding">
            open wound or bleeding<br>
            <input type="checkbox" name="other_notes[]"
               value="entanglement in a rope or net">
            entanglement in a rope or net<br>
            <input type="checkbox" name="other_notes[]"
               value="tumor visible">
            tumor visible<br>
            <input type="checkbox" name="other_notes[]"
               value="nest/hatching disturbance">
            nest/hatching disturbance<br>
            <input type="checkbox" name="other_notes[]"
               value="deceased">
            deceased<br>
            <br>
            <input type="submit" value="Done">
            </div>
         </form>
      </div>
   </body>
</html>



