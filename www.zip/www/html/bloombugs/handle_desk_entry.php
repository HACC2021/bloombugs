<?php
   require_once('../../include/bb/helpers.php');
   $pdo = connect();
   if (!$pdo) {
      die("Could not connect");
   }
   $date = trim($_POST["sighting_date"]);
   $location = trim($_POST["beach_location"]);
   //echo $location . "<br>";
   $gps = trim($_POST["gps_string"]);
   $t_type = trim($_POST["turtle_type"]);
   $notes_array = $_POST["other_notes"];
   $gps_tokens = explode(",",$gps);
   $lat = $gps_tokens[0];
   $long = $gps_tokens[1];
   $other_notes = "";
   //var_dump($notes_array);
   //echo "<br>";
   //echo $notes_array[0] . "<br>";
   for ($i = 0; $i < count($notes_array); $i++) {
      $other_notes = $other_notes . $notes_array[$i] . "\n";
   }
   //echo "$date<br>";
   //echo "$location<br>";
   //echo "<br>$lat<br>";
   //echo "$long<br>";
   //echo "$other_notes<br>";
   //echo "$t_type<br>";
   //var_dump($notes_array);
   $sql = "insert into turtles (sighting_date, beach_location, " .
      "location_latitude, location_longitude, turtle_type, " .
      "other_notes) values (:date, :loc, :lat, :long, :t_type, " .
      ":notes)";
   //echo "<br>$sql<br>";
   $statement = $pdo->prepare($sql);
   $myarray = array();
   $myarray[':date'] = $date;
   $myarray[':loc'] = $location;
   $myarray[':lat'] = $lat;
   $myarray[':long'] = $long;
   $myarray[':t_type'] = $t_type;
   $myarray[':notes'] = $other_notes;
   $statement->execute($myarray);
   header("Location: home.php");
   exit();
?>
