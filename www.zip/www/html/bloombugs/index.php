<?php
  echo "Hello from PHP\n";
?>
