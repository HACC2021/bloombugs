<?php
   require_once('../../include/bb/helpers.php');
   function fix_turtle_type($t_type) {
      if ($t_type == 'Cm') {
         return "$t_type - Green turtle";
      }
      else if ($t_type == 'Ei') {
         return "$t_type - Hawksbill turtle";
      }
      else if ($t_type == 'Cc') {
         return "$t_type - Loggerhead turtle";
      }
      else if ($t_type == 'Dc') {
         return "$t_type - Leatherback turtle";
      }
      else if ($t_type == 'Lo') {
         return "$t_type - Olive Ridley turtle";
      }
   }
   $pdo = connect();
   if (!$pdo) {
      die("Could not connect");
   }
   $sql = "select sighting_date, beach_location, location_latitude, location_longitude, turtle_type, other_notes from turtles";
   $results = $pdo->query($sql);
   $turtle_data = "";
   while ($row = $results->fetch(PDO::FETCH_ASSOC)) {
      $turtle_data .= "<tr>\n";
      $turtle_data .= "<td>" . $row["sighting_date"] . "</td>\n";
      $turtle_data .= "<td>" . $row["beach_location"] . "</td>\n";
      $turtle_data .= "<td>" . $row["location_latitude"] . "</td>\n";
      $turtle_data .= "<td>" . $row["location_longitude"] . "</td>\n";
      $turtle = fix_turtle_type($row["turtle_type"]);
      $turtle_data .= "<td>" . $turtle . "</td>\n";
      $turtle_data .= "<td>" . $row["other_notes"] . "</td>\n";
      $turtle_data .= "</tr>\n";
   }
?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <link type="text/css" rel="stylesheet" 
         href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
      <script src="https://code.jquery.com/jquery-2.2.4.min.js">
      </script>
      <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js">
      </script>
      <script>
         $(document).ready( function () {
            $('#turtle_table').DataTable();
         } );
      </script>
   </head>
   <body>
      <a href="desk_entry.php">Back to entry page</a><br>
      <table id="turtle_table" class="stripe hover" border="1">
         <thead>
            <tr>
               <th>Date</th> <th>Beach/Location</th> 
               <th>GPS latitude</th> <th>GPS longitude</th>
               <th>Turtle type</th> <th>Other notes</th>
            </tr>
         </thead>
         <tbody>
<?php echo $turtle_data; ?>
         </tbody>
      </table>
   </body>
</html>
