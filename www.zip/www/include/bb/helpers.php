<?php
   function connect() {
      $dsn = "mysql:host=localhost;dbname=hacc_db";
      $user = 'bob';
      $password='somepass';
      $pdo = new PDO($dsn, $user, $password);
      return $pdo;
   }
?>
